#include <iostream>
using namespace std;
class Percent
{
public:
	friend bool operator ==(const Percent& first,
		const Percent& second);
	friend bool operator <(const Percent& first,
		const Percent& second);
	Percent();
	Percent(int aValue) {
		value = aValue;
	}
	int getValue() const {
		return value;
	}
	friend istream& operator >>(istream& inputStream,
		Percent& aPercent);
	friend ostream& operator <<(ostream& outputStream,
		const Percent& aPercent);

	friend Percent operator+(Percent p1, Percent p2);
	friend Percent operator-(Percent p1, Percent p2);
	friend Percent operator*(Percent p1, Percent p2);
	friend Percent operator/(Percent pq, Percent p2);
	//There will be other members and friends.
private:
	int value;
};
Percent operator+(Percent p1, Percent p2) {
	Percent temp(p1.value + p2.value);
	return temp;
}
Percent operator-(Percent p1, Percent p2) {
	Percent temp(p1.value - p2.value);
	return temp;
}
Percent operator*(Percent p1, Percent p2) {
	Percent temp(p1.value*p2.value);
	return temp / 100;
}
Percent operator/(Percent p1, Percent p2) {
	Percent temp(p1.value / p2.value);
	return temp;
}
int main() {
	int value;
	cout << "Enter a percentage" << endl;
	cin >> value;
	Percent p1(value);
	cout << "Enter a percentage" << endl;
	cin >> value;
	Percent p2(value);
	Percent total = p1 + p2;
	cout << endl << "Added: " << total.getValue() << "%" << endl;
	total = p1 - p2;
	cout << "Subtracted: "<< total.getValue() << "%" << endl;
	total = p1 * p2;
	cout << "Multplied: "<< total.getValue() << "%" << endl;
	
	
}