#include <iostream>
using namespace std;

class Money {
private:
	char* name;
	int major;
	int minor;
public:
	Money();
	Money(char currencyName[10], int majorType, int minorType) {
		name = currencyName;
		major = majorType;
		minor = minorType;
	}
	friend Money operator-(Money m1, Money m2);
	friend Money operator*(Money m1, int amount);
	friend Money operator/(Money m1, double amount);
	friend ostream& operator<<(ostream& output, const Money& m1);
	friend bool operator==(Money& m1, Money& m2);
	friend bool operator<(Money& m1, Money& m2);
};
Money operator-(Money m1, Money m2) {
	return Money(m1 - m2);
	}
Money operator*(Money m1, int amount) {
	return Money(m1 * amount);
}
Money operator/(Money m1, double amount) {
	return Money(m1 / amount);
}
bool operator==(Money& m1, Money& m2) {

}
int main() {
	char name[10];
	cout << "Enter a currency name";
	cin << name;
	
}